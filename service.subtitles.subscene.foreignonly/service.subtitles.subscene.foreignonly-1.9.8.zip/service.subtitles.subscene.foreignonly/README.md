service.subtitles.subscene.foreignonly
======================================

Subscene.com subtitle service plugin for Kodi searching for subs for foreign parts only.

Fork of jarmo's subscene subtitle addon (https://github.com/jarmo/service.subtitles.subscene) which is a fork of CrowleyAJ's addon (https://github.com/manacker/service.subtitles.subscene). 

Forum thread: http://forum.xbmc.org/showthread.php?tid=184854
