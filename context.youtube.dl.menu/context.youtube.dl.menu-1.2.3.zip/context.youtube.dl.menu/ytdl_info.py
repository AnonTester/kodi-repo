# -*- coding: utf-8 -*-
import xbmcaddon

if __name__ == '__main__':
    xbmc.executebuiltin("RunScript(script.module.youtube.dl,INFO)")
