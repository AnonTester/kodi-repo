# Kodi After Watch add-on
Based on Pynto R's great work, see https://code.google.com/archive/p/hautopc/ 

This add-on allows you to automatically delete or move files after watching movies or TV episodes

Tested with Kodi 19 (Matrix), but should works with at least Kodi 14 (Helix).
