# Kodi After Watch add-on
Based on Pynto R's great work, see https://code.google.com/archive/p/hautopc/ 

This add-on allows you to automatically delete, move and/or rate files after watching movies or TV episodes

Tested with Kodi 20 (Nexus). As of add-on v1.3.0, Kodi versions before 18 (Matrix) are no longer supported.
