# -*- coding: utf-8 -*-
#
# Copyright (C) 2014 Thomas Amland
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import re
import xbmc
import json
import xbmcaddon

__addon__ = xbmcaddon.Addon()


def log(msg, level=xbmc.LOGINFO):
    if setting('debug') == 'true' or level >= xbmc.LOGWARNING:
        xbmc.log(('[%s] %s' % (info('name'), msg)), level)


def info(sid):
    return __addon__.getAddonInfo(sid)


def lang(sid):
    return __addon__.getLocalizedString(sid)


def setting(sid):
    return __addon__.getSetting(sid)


def set_setting(sid, val):
    __addon__.setSetting(sid, val)


def is_url(path):
    return re.match(r'^[A-z]+://', path) is not None


def escape_param(s):
    escaped = s.replace('\\', '\\\\').replace('"', '\\"')
    return '"' + escaped + '"'


def rpc(method, **params):
    params = json.dumps(params)
    query = '{"jsonrpc": "2.0", "method": "%s", "params": %s, "id": 1}' % (method, params)
    return json.loads(xbmc.executeJSONRPC(query))
