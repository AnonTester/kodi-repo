# -*- coding: utf-8 -*-
import xbmc
from resources.lib.utils import setting, log
from resources.lib import dialog


class Debug(object):
    enabled = False
    traceback = None

    def __init__(self):
        self.set()

    def import_traceback(self):
        self.traceback = __import__('traceback')

    def exception_dialog(self, error):
        if not debug.get():
            log(error, xbmc.LOGERROR)
        dialog.error(error)

    def set(self):
        if setting('debug') == 'true':
            self.import_traceback()
            self.enabled = True
        else:
            self.enabled = False

    def get(self):
        return self.enabled

debug = Debug()
