# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
from resources.lib.utils import info, lang, setting


def proceed(title, subtitle):
    proceedcheck = True
    if setting('confirm') == 'true':
        proceedcheck = xbmcgui.Dialog().yesno(info('name'), title + "\n" + lang(30526) % subtitle)
    return proceedcheck


def warning(module, count):
    proceedcheck = True
    threshold = int(setting('fm_warn'))
    if count > threshold:
        proceedcheck = xbmcgui.Dialog().yesno(info('name'), lang(30588) % (module, count))
    return proceedcheck


def error(msg):
    xbmcgui.Dialog().ok(info('name'), str(msg))


def notification(msg):
    xbmc.executebuiltin('Notification(%s,%s,5000,%s)' % (info('name'), msg, info('icon')))
    # todo xbmcgui.Dialog().notification('Movie Trailers', 'Finding Nemo download finished.',
    #  xbmcgui.NOTIFICATION_INFO, 5000)


def rating(title):
    options = ['10 **********', '9 *********', '8 ********', '7 *******', '6 ******',
               '5 *****', '4 ****', '3 ***', '2 **', '1 *']
    i = xbmcgui.Dialog().select(lang(30512) % (info('name'), title), options)
    if not i == -1:
        ratingvalue = 10 - i
        return ratingvalue

def ValueErrorHandler(err):
    if err[0] == 'xbmcvfs.mkdirs':
        log("ValueError Exception: Error creating folder: %s" % err[1])
        dialog.error(lang(30611) + ' %s' % err[1])
    if err[0] == 'xbmcvfs.rmdir':
        log("ValueError Exception: Error removing folder: %s" % err[1])
        dialog.error(lang(30612) + ' %s' % err[1])
    if err[0] == 'xbmcvfs.delete':
        log("ValueError Exception: Error removing file: %s" % err[1])
        dialog.error(lang(30613) + ' %s' % err[1])
    if err[0] == 'xbmcvfs.copy':
        log("ValueError Exception: Error copying %s to %s" % (err[1], err[2]))
        dialog.error(lang(30614) + ' %s -> %s' % (err[1], err[2]))
    if err[0] == 'os.remove':
        log("ValueError Exception: Error removing file: %s" % err[1])
        dialog.error(lang(30613) + ' %s' % err[1])
    if err[0] == 'os.rmdir':
        log("ValueError Exception: Error removing folder: %s" % err[1])
        dialog.error(lang(30612) + ' %s' % err[1])
